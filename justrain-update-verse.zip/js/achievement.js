// ====================================================
// achievement.js — single random on enter (glass UI)
// ====================================================

(function () {

  const STORAGE_KEY = 'achievement-shown-once';

  const achievements = [
    {
      title: "Хорошего прочтения",
      description: "Пусть эта история принесёт вам уют и спокойствие."
    },
    {
      title: "Первопроходец",
      description: "Вы впервые открыли эту страницу. Добро пожаловать."
    },
    {
      title: "Цитата пути",
      description: "«Каждый читатель - это новый мир, открывающий страницу за страницей.»"
    }
  ];

  // ─────────────────────────────
  // STYLE (FULL CSS INSIDE JS)
  // ─────────────────────────────
  const style = document.createElement('style');

  style.textContent = `
    .achv-container {
      position: fixed;
      top: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      z-index: 99999;
    }

    .achv {
      display: flex;
      align-items: center;
      gap: 12px;

      width: 270px;
      padding: 12px 14px;

      border-radius: 14px;

      background: rgba(20, 20, 20, 0.45);
      backdrop-filter: blur(14px);

      border: 1px solid rgba(255,255,255,0.15);

      box-shadow: 0 10px 30px rgba(0,0,0,0.35);

      color: var(--text, #fff);

      animation: achvIn 0.4s ease;

      overflow: hidden;
    }

    .achv-icon {
      width: 42px;
      height: 42px;
      border-radius: 50%;

      display: flex;
      align-items: center;
      justify-content: center;

      border: 2px solid #4caf50;

      background: rgba(0, 0, 0, 0.5);

      color: #ffd54a;

      flex-shrink: 0;

      box-shadow: 0 0 10px rgba(76, 175, 80, 0.35);
    }

    .achv-icon svg {
      width: 22px;
      height: 22px;
      filter: drop-shadow(0 0 4px rgba(255, 215, 0, 0.4));
    }

    .achv-title {
      font-weight: 700;
      font-size: 14px;
      margin-bottom: 3px;
    }

    .achv-desc {
      font-size: 12px;
      opacity: 0.85;
      line-height: 1.2;
    }

    @keyframes achvIn {
      from {
        opacity: 0;
        transform: translateY(-12px) scale(0.95);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }
  `;

  document.head.appendChild(style);

  // ─────────────────────────────
  // CONTAINER
  // ─────────────────────────────
  const container = document.createElement('div');
  container.className = 'achv-container';
  document.body.appendChild(container);

  // ─────────────────────────────
  // STAR ICON
  // ─────────────────────────────
  function starSVG() {
    return `
      <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
        <path d="M32 6L39 24H58L42 35L48 54L32 42L16 54L22 35L6 24H25Z"
              fill="currentColor"/>
      </svg>
    `;
  }

  // ─────────────────────────────
  // CREATE ACHIEVEMENT
  // ─────────────────────────────
  function createAchievement(data) {

    const el = document.createElement('div');
    el.className = 'achv';

    el.innerHTML = `
      <div class="achv-icon">${starSVG()}</div>
      <div>
        <div class="achv-title">${data.title}</div>
        <div class="achv-desc">${data.description}</div>
      </div>
    `;

    container.appendChild(el);

    setTimeout(() => {
      el.style.transition = '0.5s ease';
      el.style.opacity = '0';
      el.style.transform = 'translateY(-10px)';
      setTimeout(() => el.remove(), 500);
    }, 4500);
  }

  // ─────────────────────────────
  // RANDOM PICK
  // ─────────────────────────────
  function randomAchievement() {
    return achievements[Math.floor(Math.random() * achievements.length)];
  }

  // ─────────────────────────────
  // INIT (ONLY ONCE EVER PER PAGE LOAD)
  // ─────────────────────────────
  window.addEventListener('DOMContentLoaded', () => {

    // ❗ гарантируем 1 запуск даже при повторном вызове скрипта
    if (window.__ACHIEVEMENT_SHOWN__) return;
    window.__ACHIEVEMENT_SHOWN__ = true;

    // optional защита от повторов через session
    if (sessionStorage.getItem(STORAGE_KEY)) return;
    sessionStorage.setItem(STORAGE_KEY, 'true');

    const achv = randomAchievement();

    setTimeout(() => {
      createAchievement(achv);
    }, 600);

  });

})();