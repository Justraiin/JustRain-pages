// ====================================================
//  book-data.js — заполняет index.html из book.json
//  Подключить: <script src="js/book-data.js"></script>
// ====================================================

(function () {

  // Конвертер числа в римские цифры
  function toRoman(n) {
    const vals = [1000,900,500,400,100,90,50,40,10,9,5,4,1];
    const syms = ['M','CM','D','CD','C','XC','L','XL','X','IX','V','IV','I'];
    let result = '';
    for (let i = 0; i < vals.length; i++) {
      while (n >= vals[i]) { result += syms[i]; n -= vals[i]; }
    }
    return result;
  }

  fetch('book.json')
    .then(r => r.json())
    .then(book => {

      // Заголовок страницы
      document.title = book.title + ' — JustRain Pages';

      // Название книги
      const titleEl = document.querySelector('.book-title');
      if (titleEl) titleEl.textContent = book.title;

      // Автор
      const authorEl = document.querySelector('.book-author');
      if (authorEl) authorEl.textContent = 'Автор: ' + book.author;

      // Мета-поля: берём все пары meta-label + meta-value
      const labels = document.querySelectorAll('.meta-label');
      labels.forEach(label => {
        const value = label.nextElementSibling;
        if (!value) return;
        const text = label.textContent.trim().replace(':', '').trim().toLowerCase();
        if (text === 'жанр')   value.textContent = book.genre   || '';
        if (text === 'дата')   value.textContent = book.date    || '';
        if (text === 'глав')   value.textContent = book.chapters_count !== undefined
                                                    ? book.chapters_count
                                                    : '';
        if (text === 'часть')  value.textContent = book.part    || '';
        if (text === 'статус') value.textContent = book.status  || '';
      });

      // Аннотация
      const annoEl = document.querySelector('.synopsis-text');
      if (annoEl && book.annotation) {
        // Сохраняем переносы строк
        annoEl.innerHTML = book.annotation
          .split('\n')
          .map(line => line.trim())
          .filter(line => line.length > 0)
          .join('<br><br>');
      }

    })
    .catch(err => console.warn('book-data.js: не удалось загрузить book.json', err));

})();
