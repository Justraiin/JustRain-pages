// ====================================================
//  scroll-top.js — кнопка "наверх"
//  Картинку положить: ui/scroll-top.png
//  Подключить: <script src="js/scroll-top.js"></script>
// ====================================================

(function () {

  const CSS = `
    #scrollTopBtn {
      position: fixed;
      bottom: 28px;
      right: 20px;
      width: 48px;
      height: 48px;
      border: none;
      background: none;
      padding: 0;
      cursor: pointer;
      z-index: 999;
      opacity: 0;
      transform: translateY(12px);
      transition: opacity 0.25s ease, transform 0.25s ease;
      pointer-events: none;
      -webkit-tap-highlight-color: transparent;
    }
    #scrollTopBtn.visible {
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    }
    #scrollTopBtn:active {
      transform: translateY(2px) scale(0.93);
    }
    #scrollTopBtn img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      display: block;
    }
  `;

  // Вставляем стили
  const style = document.createElement('style');
  style.textContent = CSS;
  document.head.appendChild(style);

  // Создаём кнопку
  const btn = document.createElement('button');
  btn.id = 'scrollTopBtn';
  btn.setAttribute('aria-label', 'Наверх');

  const img = document.createElement('img');
  img.src = 'ui/scroll-top.png';
  img.alt = '';
  btn.appendChild(img);

  // Вставляем в body как только DOM готов
  function mount() {
    document.body.appendChild(btn);

    // Показываем кнопку после скролла на 300px
    let scrollTimer = null;
    window.addEventListener('scroll', () => {
      clearTimeout(scrollTimer);
      scrollTimer = setTimeout(() => {
        btn.classList.toggle('visible', window.scrollY > 300);
      }, 80);
    }, { passive: true });

    // Клик — плавный скролл наверх
    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
  } else {
    mount();
  }

})();
