// ============================================================
//  description.js — ТОЛЬКО для index.html (Главная страница)
// ============================================================

(function () {
    var overlay = document.getElementById('continueOverlay');
    // Проверяем, существуют ли кнопки, чтобы избежать ошибок если их нет
    var continueBtn = document.getElementById('continueBtn');
    var restartBtn = document.getElementById('restartBtn');
    var progressItem = document.getElementById('indexProgressItem');

    function getProgress() {
        try { return JSON.parse(localStorage.getItem('reader-progress')) || null; }
        catch (e) { return null; }
    }

    function setPct(barId, pct) {
        var bar = document.getElementById(barId);
        if (!bar) return;
        bar.style.setProperty('--value', pct);
        bar.setAttribute('aria-valuenow', pct);
        var lbl = bar.querySelector('.rp-label');
        if (lbl) lbl.textContent = pct + '%';
    }

    function updateIndexBar() {
        var p = getProgress();
        var pct = p ? Math.round(p.ratio * 100) : 0;
        setPct('readProgressBar', pct);
        if (progressItem) progressItem.style.display = pct > 0 ? '' : 'none';
    }

    // Инициализация при загрузке
    updateIndexBar();
    
    var mb = document.getElementById('menuBtn');
    if (mb) mb.addEventListener('click', updateIndexBar);

    // Глобальная функция для кнопки "Читать книгу"
    window.openReadDialog = function () {
        var p = getProgress();
        
        // Если прогресс есть и он больше 0.5%
        if (p && p.ratio > 0.005) {
            var pct = Math.round(p.ratio * 100);
            setPct('dialogProgressBar', pct);
            
            var subEl = document.getElementById('continueSubEl');
            if(subEl) subEl.textContent = 'Вы прочитали ' + pct + '% книги';
            
            if(overlay) overlay.classList.add('show');
        } else {
            // Если прогресса нет, идем сразу на загрузчик
            window.location.href = 'loader.html';
        }
    };

    // Обработчики внутри диалога
    if (overlay) {
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) overlay.classList.remove('show');
        });
    }

    if (continueBtn) {
        continueBtn.addEventListener('click', function () {
            if(overlay) overlay.classList.remove('show');
            var p = getProgress();
            if (p && p.scrollY != null) {
                sessionStorage.setItem('reader-resume-scroll', p.scrollY);
            }
            window.location.href = 'reader.html'; // Или loader.html, если reader сам грузит прогресс
        });
    }

    if (restartBtn) {
        restartBtn.addEventListener('click', function () {
            localStorage.removeItem('reader-progress');
            if(overlay) overlay.classList.remove('show');
            updateIndexBar();
            window.location.href = 'loader.html';
        });
    }

})();