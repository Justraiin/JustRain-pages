// ====================================================
//  .reader — bookmark.js
//  Sticky bookmark with smart snap
// ====================================================

(function () {

  /* ─────────────────────────────────────────────
     DOM
  ───────────────────────────────────────────── */
  const menuList = document.getElementById('menuList');
  const header   = document.querySelector('header');

  if (!menuList || !header) return;

  /* ─────────────────────────────────────────────
     STATE
  ───────────────────────────────────────────── */
  const STORAGE_KEY = 'reader-bookmark';

  let bookmarkEl = null;

  let isDragging = false;
  let isFrozen   = false;

  let dragOffsetX = 0;
  let dragOffsetY = 0;

  let freezeTimer = null;

  /* ─────────────────────────────────────────────
     MENU BUTTON
  ───────────────────────────────────────────── */
  const btnLi = document.createElement('li');

  btnLi.style.cssText = `
    padding: 6px 10px;
    border-top: 1px solid var(--div);
  `;

  const bookmarkBtn = document.createElement('button');

  bookmarkBtn.className = 'theme-button';
  bookmarkBtn.textContent = 'Добавить закладку';

  btnLi.appendChild(bookmarkBtn);

  const themeLi =
    menuList.querySelector('li:last-child');

  menuList.insertBefore(btnLi, themeLi);

  /* ─────────────────────────────────────────────
     CREATE BOOKMARK
  ───────────────────────────────────────────── */
  function createBookmark() {

    const wrap = document.createElement('div');

    wrap.id = 'reader-bookmark';

    wrap.innerHTML = `

      <div class="bookmark-loader">
        <svg viewBox="0 0 40 40">

          <circle class="loader-bg"
                  cx="20"
                  cy="20"
                  r="17" />

          <circle class="loader-ring"
                  cx="20"
                  cy="20"
                  r="17" />

        </svg>
      </div>

      <img src="ui/bookmark.png"
           alt="bookmark"
           draggable="false">
    `;

    wrap.style.cssText = `
      position: absolute;

      width: 34px;

      z-index: 9999;

      user-select: none;
      touch-action: none;

      cursor: grab;

      transform-origin: center;

      filter:
        drop-shadow(0 3px 10px rgba(0,0,0,.35));
    `;

    const img = wrap.querySelector('img');

    img.style.cssText = `
      width: 100%;
      display: block;
      position: relative;
      z-index: 2;
      pointer-events: none;
    `;

    /* loader */

    const loader =
      wrap.querySelector('.bookmark-loader');

    loader.style.cssText = `
      position: absolute;

      inset: -9px;

      z-index: 1;

      pointer-events: none;

      transition: opacity .2s;
    `;

    const svg = loader.querySelector('svg');

    svg.style.cssText = `
      width: 100%;
      height: 100%;

      transform: rotate(-90deg);
    `;

    const bg =
      loader.querySelector('.loader-bg');

    bg.style.cssText = `
      fill: none;

      stroke:
        rgba(255,255,255,.12);

      stroke-width: 3;
    `;

    const ring =
      loader.querySelector('.loader-ring');

    ring.style.cssText = `
      fill: none;

      stroke: #ffffff;

      stroke-width: 3;

      stroke-linecap: round;

      stroke-dasharray: 107;
      stroke-dashoffset: 107;

      transition:
        stroke-dashoffset 2s linear;
    `;

    document.body.appendChild(wrap);

    return wrap;
  }

  /* ─────────────────────────────────────────────
     STORAGE
  ───────────────────────────────────────────── */
  function saveBookmark(x, y, frozen) {

    localStorage.setItem(
      STORAGE_KEY,

      JSON.stringify({
        x,
        y,
        frozen
      })
    );
  }

  function loadBookmark() {

    try {

      return JSON.parse(
        localStorage.getItem(STORAGE_KEY)
      );

    } catch {

      return null;
    }
  }

  function clearBookmark() {

    localStorage.removeItem(STORAGE_KEY);
  }

  /* ─────────────────────────────────────────────
     HELPERS
  ───────────────────────────────────────────── */
  function setPos(el, x, y) {

    el.style.left = x + 'px';
    el.style.top  = y + 'px';
  }

  function headerCenter() {

    const rect =
      header.getBoundingClientRect();

    return {

      x:
        rect.left +
        rect.width / 2 -
        17,

      y:
        rect.bottom +
        8 +
        window.scrollY
    };
  }

  /* ─────────────────────────────────────────────
     FREEZE TIMER
  ───────────────────────────────────────────── */
  function startFreezeCountdown() {

    if (!bookmarkEl) return;

    clearTimeout(freezeTimer);

    isFrozen = false;

    const ring =
      bookmarkEl.querySelector('.loader-ring');

    const loader =
      bookmarkEl.querySelector('.bookmark-loader');

    loader.style.opacity = '1';

    ring.style.transition = 'none';
    ring.style.strokeDashoffset = '107';

    requestAnimationFrame(() => {

      requestAnimationFrame(() => {

        ring.style.transition =
          'stroke-dashoffset 2s linear';

        ring.style.strokeDashoffset = '0';
      });
    });

    freezeTimer = setTimeout(() => {

      freezeBookmark();

    }, 2000);
  }

  function freezeBookmark() {

    if (!bookmarkEl) return;

    isFrozen = true;

    const rect =
      bookmarkEl.getBoundingClientRect();

    saveBookmark(
      rect.left,
      rect.top + window.scrollY,
      true
    );

    const loader =
      bookmarkEl.querySelector('.bookmark-loader');

    loader.style.opacity = '.35';
  }

  /* ─────────────────────────────────────────────
     SNAP TO TEXT
  ───────────────────────────────────────────── */
  function snapToText() {

    if (!bookmarkEl) return;

    const rect =
      bookmarkEl.getBoundingClientRect();

    const centerY =
      rect.top + rect.height / 2;

    const texts =
      document.querySelectorAll('.chapter-text');

    let best = null;
    let bestDist = Infinity;

    texts.forEach(node => {

      const r =
        node.getBoundingClientRect();

      const lineH =
        parseFloat(
          getComputedStyle(node).lineHeight
        ) || 28;

      const lines =
        Math.round(r.height / lineH);

      for (let i = 0; i <= lines; i++) {

        const lineY =
          r.top + i * lineH;

        const dist =
          Math.abs(centerY - lineY);

        if (dist < bestDist) {

          bestDist = dist;

          best = {

            /* справа от текста */
            x:
              r.right - 10,

            y:
              lineY + window.scrollY
          };
        }
      }
    });

    if (!best) return;

    bookmarkEl.style.transition =
      'left .18s ease, top .18s ease';

    setPos(
      bookmarkEl,
      best.x,
      best.y
    );

    setTimeout(() => {

      if (bookmarkEl) {

        bookmarkEl.style.transition = '';
      }

    }, 180);

    saveBookmark(
      best.x,
      best.y,
      true
    );
  }

  /* ─────────────────────────────────────────────
     DRAG START
  ───────────────────────────────────────────── */
  function beginDrag(clientX, clientY) {

    if (!bookmarkEl) return;

    isDragging = true;
    isFrozen   = false;

    clearTimeout(freezeTimer);

    const rect =
      bookmarkEl.getBoundingClientRect();

    dragOffsetX =
      clientX - rect.left;

    dragOffsetY =
      clientY - rect.top;

    bookmarkEl.style.cursor =
      'grabbing';

    bookmarkEl.style.transition = '';

    const loader =
      bookmarkEl.querySelector('.bookmark-loader');

    loader.style.opacity = '1';
  }

  /* ─────────────────────────────────────────────
     DRAG MOVE
  ───────────────────────────────────────────── */
  function moveDrag(clientX, clientY) {

    if (!isDragging || !bookmarkEl) return;

    /* свободное перемещение */

    setPos(
      bookmarkEl,

      clientX - dragOffsetX,

      clientY -
      dragOffsetY +
      window.scrollY
    );
  }

  /* ─────────────────────────────────────────────
     DRAG END
  ───────────────────────────────────────────── */
  function endDrag() {

    if (!bookmarkEl) return;

    isDragging = false;

    bookmarkEl.style.cursor =
      'grab';

    /* после отпускания
       перенос вправо */

    snapToText();

    startFreezeCountdown();
  }

  /* ─────────────────────────────────────────────
     EVENTS
  ───────────────────────────────────────────── */
  function attachDrag(el) {

    /* mouse */

    el.addEventListener('mousedown', e => {

      beginDrag(
        e.clientX,
        e.clientY
      );

      document.addEventListener(
        'mousemove',
        mouseMove
      );

      document.addEventListener(
        'mouseup',
        mouseUp
      );

      e.preventDefault();
    });

    /* touch */

    el.addEventListener('touchstart', e => {

      const t = e.touches[0];

      beginDrag(
        t.clientX,
        t.clientY
      );

      document.addEventListener(
        'touchmove',
        touchMove,
        { passive: false }
      );

      document.addEventListener(
        'touchend',
        touchEnd
      );

      e.preventDefault();

    }, { passive: false });
  }

  function mouseMove(e) {

    moveDrag(
      e.clientX,
      e.clientY
    );
  }

  function mouseUp() {

    document.removeEventListener(
      'mousemove',
      mouseMove
    );

    document.removeEventListener(
      'mouseup',
      mouseUp
    );

    endDrag();
  }

  function touchMove(e) {

    const t = e.touches[0];

    moveDrag(
      t.clientX,
      t.clientY
    );

    e.preventDefault();
  }

  function touchEnd() {

    document.removeEventListener(
      'touchmove',
      touchMove
    );

    document.removeEventListener(
      'touchend',
      touchEnd
    );

    endDrag();
  }

  /* ─────────────────────────────────────────────
     SHOW
  ───────────────────────────────────────────── */
  function showBookmark() {

    if (bookmarkEl) return;

    bookmarkEl = createBookmark();

    attachDrag(bookmarkEl);

    const saved =
      loadBookmark();

    if (saved) {

      setPos(
        bookmarkEl,
        saved.x,
        saved.y
      );

      isFrozen =
        saved.frozen;

    } else {

      const c =
        headerCenter();

      setPos(
        bookmarkEl,
        c.x,
        c.y
      );

      saveBookmark(
        c.x,
        c.y,
        false
      );

      startFreezeCountdown();
    }

    bookmarkBtn.textContent =
      '🎀 Убрать закладку';
  }

  /* ─────────────────────────────────────────────
     HIDE
  ───────────────────────────────────────────── */
  function hideBookmark() {

    clearTimeout(freezeTimer);

    if (bookmarkEl) {

      bookmarkEl.remove();

      bookmarkEl = null;
    }

    clearBookmark();

    bookmarkBtn.textContent =
      '🎀 Добавить закладку';
  }

  /* ─────────────────────────────────────────────
     BUTTON
  ───────────────────────────────────────────── */
  bookmarkBtn.addEventListener('click', () => {

    menuList.classList.remove('show');

    if (bookmarkEl) {

      hideBookmark();

    } else {

      showBookmark();
    }
  });

  /* ─────────────────────────────────────────────
     RESTORE
  ───────────────────────────────────────────── */
  window.addEventListener(
    'DOMContentLoaded',
    () => {

      const saved =
        loadBookmark();

      if (saved) {

        showBookmark();
      }
    }
  );

})();