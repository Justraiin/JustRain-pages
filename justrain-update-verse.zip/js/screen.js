document.addEventListener("DOMContentLoaded", () => {
    const tooltip = document.getElementById("quoteTooltip");
    const modal = document.getElementById("quoteModal");
    const modalText = document.getElementById("modalQuoteText");
    const closeBtn = document.getElementById("closeQuoteBtn");
    const copyBtn = document.getElementById("copyQuoteBtn");

    let selectedText = "";

    // 1. Отслеживаем выделение текста
    document.addEventListener("selectionchange", () => {
        const selection = window.getSelection();
        selectedText = selection.toString().trim();

        if (selectedText.length > 5) { // Показываем кнопку только если выделено больше 5 символов
            const range = selection.getRangeAt(0);
            const rect = range.getBoundingClientRect();

            // Позиционируем кнопку строго над выделенным текстом
            tooltip.style.left = `${rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + window.scrollX}px`;
            tooltip.style.top = `${rect.top - tooltip.offsetHeight - 8 + window.scrollY}px`;
            tooltip.style.display = "block";
        } else {
            tooltip.style.display = "none";
        }
    });

    // 2. Нажатие на всплывающую кнопку «Цитата»
    tooltip.addEventListener("click", (e) => {
        e.stopPropagation();
        modalText.textContent = `«${selectedText}»`;
        modal.style.display = "flex";
        tooltip.style.display = "none";
        window.getSelection().removeAllRanges(); // Снимаем выделение
    });

    // 3. Закрытие модального окна
    closeBtn.addEventListener("click", () => {
        modal.style.display = "none";
    });

    // 4. Копирование текста из карточки
    copyBtn.addEventListener("click", () => {
        navigator.clipboard.writeText(modalText.textContent).then(() => {
            copyBtn.textContent = "Скопировано!";
            setTimeout(() => { copyBtn.textContent = "Копировать"; }, 2000);
        });
    });

    // Закрытие при клике на оверлей вне карточки
    modal.addEventListener("click", (e) => {
        if (e.target === modal) modal.style.display = "none";
    });
});
