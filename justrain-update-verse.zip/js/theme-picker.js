/* ============================================================
   theme-picker.js  —  панель выбора темы
   Подключить: <script src="js/theme-picker.js"></script>
   Заменить кнопку темы в меню на:
     <li><button id="themeBtn" class="theme-button">◑ Тема: Морская</button></li>
   Файл сам вставит стили и создаст панель. Больше ничего не нужно.
   ============================================================ */

(function () {

  /* ── 1. Данные тем ───────────────────────────────────────── */
  const THEMES = [
    { id: 't-1',  name: 'Тёплая',    bg: '#ede0d4', accent: '#1a1625', dark: false },
    { id: 't-2',  name: 'Морская',   bg: '#cde8f5', accent: '#0d4a70', dark: false },
    { id: 't-3',  name: 'Пастель',   bg: '#f0e4f6', accent: '#6b2d8b', dark: false },
    { id: 't-4',  name: 'Янтарь',    bg: '#0e0c08', accent: '#e09820', dark: true  },
    { id: 't-5',  name: 'Алая',      bg: '#0d0810', accent: '#c0004a', dark: true  },
    { id: 't-6',  name: 'Матча',     bg: '#dfe7d6', accent: '#53694d', dark: false },
    { id: 't-7',  name: 'Лето',      bg: '#fff8e7', accent: '#e07800', dark: false },
    { id: 't-8',  name: 'Холод',     bg: '#080c12', accent: '#2e5480', dark: true  },
    { id: 't-9',  name: 'Сирень',    bg: '#efe5ea', accent: '#6a4565', dark: false },
    { id: 't-10', name: 'Ночь',      bg: '#090c11', accent: '#FFD300', dark: true  },
  ];

  /* ── 2. CSS ──────────────────────────────────────────────── */
  const CSS = `
    /* Панель тем */
    #themePicker {
      display: none;
      position: absolute;
      top: calc(100% + 6px);
      right: 0;
      width: 232px;
      padding: 10px;
      border-radius: 14px;
      background: var(--menu, rgba(248,240,234,0.97));
      border: 1px solid var(--div, rgba(0,0,0,0.07));
      box-shadow: 0 8px 32px rgba(0,0,0,0.14), 0 2px 8px rgba(0,0,0,0.08);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      z-index: 9999;
      box-sizing: border-box;
    }
    #themePicker.tp-open {
      display: block;
      animation: tpFadeIn 0.18s cubic-bezier(0.34,1.56,0.64,1) both;
    }
    @keyframes tpFadeIn {
      from { opacity: 0; transform: translateY(-6px) scale(0.97); }
      to   { opacity: 1; transform: translateY(0)    scale(1);    }
    }

    /* Заголовок */
    .tp-title {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--muted, rgba(0,0,0,0.4));
      margin-bottom: 8px;
      padding: 0 2px;
    }

    /* Сетка свотчей */
    .tp-grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 6px;
    }

    /* Один свотч */
    .tp-swatch {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      cursor: pointer;
      padding: 0;
      background: none;
      border: none;
      outline: none;
      -webkit-tap-highlight-color: transparent;
    }
    .tp-circle {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      border: 2px solid transparent;
      box-shadow: 0 1px 4px rgba(0,0,0,0.18);
      transition: transform 0.15s, border-color 0.15s, box-shadow 0.15s;
      position: relative;
      overflow: hidden;
    }
    /* Полукруг — bg слева, accent справа */
    .tp-circle::before,
    .tp-circle::after {
      content: '';
      position: absolute;
      inset: 0;
    }
    .tp-circle::before {
      background: var(--tp-bg);
      clip-path: polygon(0 0, 50% 0, 50% 100%, 0 100%);
    }
    .tp-circle::after {
      background: var(--tp-accent);
      clip-path: polygon(50% 0, 100% 0, 100% 100%, 50% 100%);
    }
    .tp-swatch:hover .tp-circle {
      transform: scale(1.12);
      box-shadow: 0 3px 10px rgba(0,0,0,0.22);
    }
    .tp-swatch.tp-active .tp-circle {
      border-color: var(--tp-accent);
      transform: scale(1.08);
      box-shadow: 0 0 0 3px rgba(255,255,255,0.35), 0 3px 10px rgba(0,0,0,0.22);
    }
    .tp-label {
      font-size: 9px;
      color: var(--muted, rgba(0,0,0,0.45));
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 38px;
      text-align: center;
      line-height: 1.2;
    }
    .tp-swatch.tp-active .tp-label {
      color: var(--text, #1a1625);
      font-weight: 600;
    }

    /* Контейнер меню — нужен position:relative для позиционирования панели */
    .menu-container {
      position: relative;
    }
  `;

  /* ── 3. Вставляем стили ──────────────────────────────────── */
  const style = document.createElement('style');
  style.textContent = CSS;
  document.head.appendChild(style);

  /* ── 4. Ждём DOM ─────────────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', init);
  // На случай если скрипт подключён в конце body и DOM уже готов
  if (document.readyState !== 'loading') init();

  function init () {
    const themeBtn = document.getElementById('themeBtn');
    if (!themeBtn) return;

    /* ── Создаём панель ── */
    const picker = document.createElement('div');
    picker.id = 'themePicker';
    picker.setAttribute('role', 'dialog');
    picker.setAttribute('aria-label', 'Выбор темы');

    picker.innerHTML = `<div class="tp-title">Выбор темы</div><div class="tp-grid"></div>`;
    const grid = picker.querySelector('.tp-grid');

    THEMES.forEach(t => {
      const btn = document.createElement('button');
      btn.className = 'tp-swatch';
      btn.dataset.theme = t.id;
      btn.setAttribute('aria-label', t.name);
      btn.innerHTML = `
        <span class="tp-circle" style="--tp-bg:${t.bg};--tp-accent:${t.accent}"></span>
        <span class="tp-label">${t.name}</span>
      `;
      btn.addEventListener('click', () => applyTheme(t));
      grid.appendChild(btn);
    });

    /* Вставляем панель рядом с кнопкой темы */
    const container = themeBtn.closest('.menu-container') || themeBtn.parentElement;
    container.appendChild(picker);

    /* ── Переключение панели ── */
    themeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = picker.classList.contains('tp-open');
      picker.classList.toggle('tp-open', !isOpen);
      themeBtn.setAttribute('aria-expanded', String(!isOpen));
    });

    /* Закрыть по клику вне */
    document.addEventListener('click', (e) => {
      if (!picker.contains(e.target) && e.target !== themeBtn) {
        picker.classList.remove('tp-open');
        themeBtn.setAttribute('aria-expanded', 'false');
      }
    });

    /* Закрыть по Escape */
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        picker.classList.remove('tp-open');
        themeBtn.setAttribute('aria-expanded', 'false');
      }
    });

    /* ── Восстановить активный свотч при загрузке ── */
    refreshActive();
  }

  /* ── 5. Применить тему ───────────────────────────────────── */
  function applyTheme (t) {
    // Убираем все старые классы тем
    document.body.classList.forEach(cls => {
      if (cls.startsWith('t-')) document.body.classList.remove(cls);
    });
    document.body.classList.add(t.id);

    // Сохраняем
    try { localStorage.setItem('reader-theme', t.id); } catch (e) {}

    // Обновляем текст кнопки
    const themeBtn = document.getElementById('themeBtn');
    if (themeBtn) themeBtn.textContent = `◑ Тема: ${t.name}`;

    // Обновляем активный свотч
    refreshActive();

    // Закрываем панель
    const picker = document.getElementById('themePicker');
    if (picker) picker.classList.remove('tp-open');
  }

  /* ── 6. Подсветить активный свотч ───────────────────────── */
  function refreshActive () {
    const current = document.body.className
      .split(' ')
      .find(c => c.startsWith('t-')) || 't-1';

    document.querySelectorAll('.tp-swatch').forEach(btn => {
      btn.classList.toggle('tp-active', btn.dataset.theme === current);
    });

    // Синхронизировать текст кнопки
    const themeBtn = document.getElementById('themeBtn');
    if (themeBtn) {
      const t = THEMES.find(x => x.id === current);
      if (t) themeBtn.textContent = `◑ Тема: ${t.name}`;
    }
  }

})();
