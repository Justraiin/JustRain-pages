// ====================================================
//  chapters-data.js — строит главы в reader.html из chapters.json
//  Подключить: <script src="js/chapters-data.js"></script>
// ====================================================

(function () {

  // Конвертер числа в римские цифры
  function toRoman(n) {
    const vals = [1000,900,500,400,100,90,50,40,10,9,5,4,1];
    const syms = ['M','CM','D','CD','C','XC','L','XL','X','IX','V','IV','I'];
    let result = '';
    for (let i = 0; i < vals.length; i++) {
      while (n >= vals[i]) { result += syms[i]; n -= vals[i]; }
    }
    return result;
  }

  let bookTitle = '';
  let chaptersData = [];

  // Обновляет название вкладки по текущей видимой главе
  function updateTabTitle() {
    if (!chaptersData.length || !bookTitle) return;

    const cards = document.querySelectorAll('.chapter-card');
    let current = null;

    cards.forEach(card => {
      const rect = card.getBoundingClientRect();
      if (rect.top <= window.innerHeight * 0.5) current = card;
    });

    if (!current) return;

    const num = parseInt(current.id.replace('chapter-', ''), 10);
    const ch  = chaptersData.find(c => c.num === num);
    if (!ch) return;

    document.title = `Глава ${toRoman(ch.num)}: ${ch.title} - ${bookTitle}`;
  }

  // Загружаем book.json для названия и части в шапке reader
  function loadBookInfo() {
    fetch('book.json')
      .then(r => r.json())
      .then(book => {
        bookTitle = book.title;
        document.title = book.title + ' — JustRain Pages';
        const h2 = document.querySelector('.book-info .description h2');
        if (h2) h2.textContent = book.title;
        const partEl = document.querySelector('.book-info .description p');
        if (partEl) partEl.textContent = 'Часть: ' + (book.part || '1');
        const quoteBook = document.getElementById('quoteCardBook');
        if (quoteBook) quoteBook.textContent = '.reader / ' + book.title.toUpperCase();
      })
      .catch(() => {});
  }

  // Загружаем chapters.json и строим всё
  fetch('chapters.json')
    .then(r => r.json())
    .then(chapters => {

      chaptersData = chapters;

      const menuList  = document.getElementById('menuList');
      const container = document.querySelector('.chapters-container');

      if (!menuList || !container) return;

      // Запоминаем первый li в меню — главы вставляем перед ним.
      // Так back.js и bookmark.js которые уже вставили свои кнопки — не трогаем.
      // Если меню пустое (скрипты ещё не отработали) — просто appendChild.
      const anchor = menuList.firstElementChild || null;

      // Очищаем только карточки глав
      container.innerHTML = '';

      chapters.forEach(ch => {
        const roman = toRoman(ch.num);
        const label = `Глава ${roman}: "${ch.title}"`;
        const id    = `chapter-${ch.num}`;

        // ── Пункт меню — вставляем в начало перед кнопками ──
        const li = document.createElement('li');
        const a  = document.createElement('a');
        a.href        = '#' + id;
        a.textContent = label;
        li.appendChild(a);
        if (anchor) {
          menuList.insertBefore(li, anchor);
        } else {
          menuList.appendChild(li);
        }

        // ── Карточка главы ──
        const card = document.createElement('div');
        card.className = 'chapter-card';
        card.id        = id;

        const titleDiv = document.createElement('div');
        titleDiv.className   = 'chapter-title';
        titleDiv.textContent = label;

        const pre = document.createElement('pre');
        pre.className   = 'chapter-text';
        pre.dataset.src = `chpt/chapter-${ch.num}.txt`;

        card.appendChild(titleDiv);
        card.appendChild(pre);
        container.appendChild(card);
      });

      // Загружаем тексты глав через fetch
      container.querySelectorAll('.chapter-text').forEach(pre => {
        const src = pre.dataset.src;
        if (!src) return;
        fetch(src)
          .then(r => { if (!r.ok) throw new Error(r.status); return r.text(); })
          .then(text => { pre.textContent = text || ''; })
          .catch(() => { pre.textContent = ''; });
      });

      // Слушаем скролл для обновления вкладки
      let scrollTimer = null;
      window.addEventListener('scroll', () => {
        clearTimeout(scrollTimer);
        scrollTimer = setTimeout(updateTabTitle, 120);
      }, { passive: true });

    })
    .catch(err => console.warn('chapters-data.js: не удалось загрузить chapters.json', err));

  loadBookInfo();

})();
