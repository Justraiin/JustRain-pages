const headers = document.querySelectorAll(".item-header");

headers.forEach((header) => {
  header.addEventListener("click", () => {
    const item = header.parentElement;

    document.querySelectorAll(".item").forEach((el) => {
      if (el !== item) el.classList.remove("open");
    });

    item.classList.toggle("open");
  });
});