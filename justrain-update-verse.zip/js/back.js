// ====================================================
//  .reader — home-button.js
// ====================================================

(function () {

  const menuList = document.getElementById('menuList');

  if (!menuList) return;

  const btnLi = document.createElement('li');

  btnLi.style.cssText = `
    padding: 6px 10px;
    border-top: 1px solid var(--div);
  `;

  const homeBtn = document.createElement('button');

  homeBtn.className = 'theme-button';
  homeBtn.textContent = 'На главную';

  btnLi.appendChild(homeBtn);

  const themeLi =
    menuList.querySelector('li:last-child');

  menuList.insertBefore(btnLi, themeLi);

  homeBtn.addEventListener('click', () => {

    menuList.classList.remove('show');

    window.location.href = 'index.html';

  });

})();