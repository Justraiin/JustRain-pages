// ====================================================
//  reading-progress.js
//  Прогресс чтения (отдельно от закладки)
//  Сохраняет позицию скролла reader.html → читает index.html
// ====================================================

(function () {
  'use strict';

  const PROGRESS_KEY = 'reader-progress'; // { scrollY, ratio }

  /* ── Утилиты ── */
  function saveProgress() {
    const ratio = getScrollRatio();
    localStorage.setItem(PROGRESS_KEY, JSON.stringify({
      scrollY: window.scrollY,
      ratio: ratio
    }));
    updateProgressBar(ratio);
  }

  function loadProgress() {
    try {
      return JSON.parse(localStorage.getItem(PROGRESS_KEY)) || null;
    } catch (e) {
      return null;
    }
  }

  function getScrollRatio() {
    const docH = document.documentElement.scrollHeight - window.innerHeight;
    if (docH <= 0) return 0;
    return Math.min(1, window.scrollY / docH);
  }

  function clearProgress() {
    localStorage.removeItem(PROGRESS_KEY);
    updateProgressBar(0);
  }

  /* ── Прогресс-бар ── */
  function updateProgressBar(ratio) {
    const pct = Math.round(ratio * 100);
    const bar = document.getElementById('readProgressBar');
    if (bar) {
      bar.style.setProperty('--value', pct);
      bar.setAttribute('aria-valuenow', pct);
      const label = bar.querySelector('.rp-label');
      if (label) label.textContent = pct + '%';
    }
  }

  /* ── Инициализация в reader.html ── */
  function initReader() {
    // Сохранять при скролле (debounce)
    let saveTimer = null;
    window.addEventListener('scroll', () => {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(saveProgress, 200);
    }, { passive: true });

    // Обновить бар сразу при старте
    updateProgressBar(getScrollRatio());

    // Экспортируем для других скриптов
    window.readingProgress = { clear: clearProgress, load: loadProgress };
  }

  /* ── Инициализация в index.html ── */
  function initIndex() {
    window.readingProgress = { clear: clearProgress, load: loadProgress };
  }

  /* ── Авто-определение страницы ── */
  const isReader = document.title.includes('reader') ||
                   !!document.querySelector('.chapters-container');

  if (isReader) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initReader);
    } else {
      initReader();
    }
  } else {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initIndex);
    } else {
      initIndex();
    }
  }

})();
