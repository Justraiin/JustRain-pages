// ====================================================
//  .reader — script.js
// ====================================================

const menuBtn  = document.getElementById('menuBtn');
const menuList = document.getElementById('menuList');

// ── Menu open/close with burger animation ──
menuBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  const isOpen = menuList.classList.toggle('show');
  menuBtn.classList.toggle('open', isOpen);
  menuBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
});

// ── Close menu after clicking a link ──
menuList.querySelectorAll('a').forEach(a => {
  a.addEventListener('click', () => {
    menuList.classList.remove('show');
    menuBtn.classList.remove('open');
    menuBtn.setAttribute('aria-expanded', 'false');
  });
});

// ── Click outside menu ──
document.addEventListener('click', (e) => {
  if (
    !menuList.contains(e.target) &&
    e.target !== menuBtn &&
    !menuBtn.contains(e.target)
  ) {
    menuList.classList.remove('show');
    menuBtn.classList.remove('open');
    menuBtn.setAttribute('aria-expanded', 'false');
  }
});

// ── Load chapter texts ──
document.querySelectorAll('.chapter-text').forEach(pre => {
  const src = pre.dataset.src;
  if (!src) return;

  fetch(src)
    .then(response => {
      if (!response.ok) throw new Error(response.status);
      return response.text();
    })
    .then(text => {
      pre.textContent = text || '';
    })
    .catch(() => {
      pre.textContent = '';
    });
});