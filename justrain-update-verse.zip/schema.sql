-- ============================================================
--  JustRain Pages — D1 Schema
--  Запустить: wrangler d1 execute justrain-db --file=schema.sql
-- ============================================================

-- Книги
CREATE TABLE IF NOT EXISTS books (
  id           TEXT PRIMARY KEY,
  slug         TEXT UNIQUE NOT NULL,
  title        TEXT NOT NULL,
  author       TEXT NOT NULL DEFAULT 'JustRain',
  genre        TEXT,
  date         TEXT,
  part         TEXT DEFAULT '1',
  status       TEXT DEFAULT 'В процессе',
  annotation   TEXT,
  cover_url    TEXT,
  published    INTEGER NOT NULL DEFAULT 0,
  views        INTEGER NOT NULL DEFAULT 0,
  likes        INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Главы
CREATE TABLE IF NOT EXISTS chapters (
  id           TEXT PRIMARY KEY,
  book_id      TEXT NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  number       INTEGER NOT NULL,
  title        TEXT NOT NULL,
  published    INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(book_id, number)
);

-- Индексы
CREATE INDEX IF NOT EXISTS idx_books_published   ON books(published);
CREATE INDEX IF NOT EXISTS idx_books_slug        ON books(slug);
CREATE INDEX IF NOT EXISTS idx_chapters_book     ON chapters(book_id);
CREATE INDEX IF NOT EXISTS idx_chapters_pub      ON chapters(book_id, published);
