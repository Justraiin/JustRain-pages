# JustRain Pages — Инструкция по настройке

## Структура проекта

```
/
├── catalog/
│   └── index.html          ← Главная страница (каталог книг)
│
├── book-template/
│   ├── index.html          ← Страница книги (шаблон)
│   ├── loader.html         ← Лоадер перед ридером
│   └── reader.html         ← Читалка
│
├── admin/
│   └── admin.html          ← Панель администратора (отдельный деплой)
│
├── functions/              ← Cloudflare Pages Functions (API)
│   └── api/
│       ├── books.js                         GET /api/books
│       ├── books/[slug].js                  GET/PATCH/DELETE /api/books/:slug
│       ├── books/[slug]/cover.js            POST /api/books/:slug/cover
│       ├── books/[slug]/chapters.js         GET/POST /api/books/:slug/chapters
│       ├── chapters/[id].js                 GET/PATCH/DELETE /api/chapters/:id
│       ├── chapters/[id]/text.js            GET /api/chapters/:id/text
│       ├── views/[bookId].js                GET/POST /api/views/:bookId
│       ├── likes/[bookId].js                GET/POST /api/likes/:bookId
│       ├── stats.js                         GET /api/stats
│       └── admin/
│           ├── books.js                     GET /api/admin/books
│           └── books/[bookId]/chapters.js   GET /api/admin/books/:id/chapters
│
├── schema.sql              ← Схема D1
└── wrangler.toml           ← Конфиг Cloudflare
```

---

## Шаг 1 — Создать ресурсы Cloudflare

```bash
# 1. D1 база данных
wrangler d1 create justrain-db
# Скопируй database_id в wrangler.toml

# 2. KV хранилище
wrangler kv namespace create justrain-kv
# Скопируй id в wrangler.toml

# 3. R2 бакет для обложек
wrangler r2 bucket create justrain-covers
```

---

## Шаг 2 — Применить схему базы данных

```bash
wrangler d1 execute justrain-db --file=schema.sql
```

---

## Шаг 3 — Настроить секрет (пароль API)

Это токен, который панель admin использует для всех запросов к API.
Должен быть длинной случайной строкой — **не твой обычный пароль**.

```bash
wrangler secret put ADMIN_SECRET
# Введи что-то вроде: xK9mP2qR8nL5wJ3vB7cF1hD4
```

---

## Шаг 4 — Пароль входа в admin.html

Пароль уже настроен: **GooAddBook**

Хэш в файле `admin/admin.html`:
```javascript
const PASSWORD_HASH = '4cf5a24d0bdd435f0fe9946b98012ed6272c21f8983aada98c2e9901bf06b4e1'; // пароль: GooAddBook
```

Если захочешь сменить пароль позже — открой консоль браузера (F12) и выполни:
```javascript
crypto.subtle.digest('SHA-256', new TextEncoder().encode('новый_пароль'))
  .then(b => console.log([...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')))
```
И вставь результат вместо `PASSWORD_HASH`.

Вставь полученную строку вместо `PASSWORD_HASH`.

---

## Шаг 5 — Настроить R2 публичный домен

1. В Cloudflare Dashboard → R2 → `justrain-covers` → Settings
2. Включи **Public Access**
3. Скопируй публичный URL (вида `pub-xxxx.r2.dev` или свой домен)
4. Вставь в `wrangler.toml` → `R2_PUBLIC_URL`

---

## Шаг 6 — Деплой основного сайта

В архиве уже всё разложено как должно лежать в корне деплоя:
- `index.html` — каталог (главная)
- `loader.html`, `reader.html` — общие страницы чтения
- `book/[slug].html` — динамический шаблон страницы книги
- `css/`, `js/` — из твоего оригинального проекта (дизайн не менялся)
- `functions/` — API

Ничего переименовывать не нужно — просто загружай корень архива как есть.

```bash
# Деплой через GitHub + Cloudflare Pages (рекомендуется)
# Или через CLI:
wrangler pages deploy . --project-name=justrain-pages
```

---

## Шаг 7 — Деплой Admin панели

**Admin — это отдельный проект**, с отдельным доменом.

```bash
# В папке admin/
wrangler pages deploy . --project-name=justrain-admin
```

В настройках проекта `justrain-admin` добавь те же bindings:
- D1: `DB` → `justrain-db`
- KV: `KV` → `justrain-kv`
- R2: `R2` → `justrain-covers`
- Secret: `ADMIN_SECRET` (тот же что у основного сайта)

В `admin.html` поменяй URL API:
```javascript
const API = 'https://justrain-pages.pages.dev'; // URL основного сайта
```

---

## Как добавить новую книгу

1. Открой admin-панель
2. Нажми **+ Новая книга**
3. Заполни: название, автор, slug (например `echo-of-rain`), жанр и т.д.
4. Загрузи обложку
5. Сохрани → книга создана в D1 как черновик
6. В разделе **Главы** нажми **+ Глава**
7. Введи название главы, вставь текст или загрузи `.txt`
8. Поставь галочку "Опубликовать" если глава готова
9. Сохрани. Повторяй для каждой главы
10. Когда книга готова — нажми **Опубликовать** → появится в каталоге

Можно публиковать книгу и добавлять главы постепенно — читатели увидят только опубликованные.

---

## Структура URL

```
/                           ← Каталог всех книг
/book/echo-of-rain          ← Страница книги (через book/[slug].html)
/loader.html?book=echo-of-rain  ← Лоадер
/reader.html?book=echo-of-rain  ← Читалка

/api/books                  ← Список книг
/api/books/echo-of-rain     ← Данные книги + главы
/api/views/bookId           ← Счётчик просмотров
/api/likes/bookId           ← Лайки
/api/stats                  ← Общая статистика
```

## Структура файлов деплоя (корень основного сайта)

```
/
├── index.html         ← каталог
├── loader.html
├── reader.html
├── book/
│   └── [slug].html     ← Cloudflare Pages подставляет любой /book/* сюда
├── css/                ← из твоего оригинального проекта, дизайн не менялся
├── js/                 ← из твоего оригинального проекта
└── functions/          ← API
```

`book/[slug].html` — это динамический файл: Cloudflare Pages автоматически отдаёт
его на любой путь вида `/book/что-угодно`, а сам файл внутри через JS читает,
какой именно slug пришёл в адресе, и подгружает данные книги через `/api/books/{slug}`.
Создавать папку под каждую новую книгу не нужно — этот механизм работает "из коробки".

---

## Как связано каталог с книгами

Каталог (`/`) получает список книг через `/api/books`.
Каждая книга имеет `slug` — он используется в URL: `/book/{slug}`.

При клике на книгу в каталоге:
→ переходим на `/book/{slug}` → Cloudflare Pages отдаёт файл `book/[slug].html`
→ этот файл читает slug из своего пути (`location.pathname`) и грузит данные
  книги через `/api/books/{slug}`

`loader.html` и `reader.html` — общие файлы в корне, получают slug через `?book=`
параметр в URL (его передаёт страница книги при переходе "Читать").

---

## KV — что хранится

```
views:book:{id}         → "1847"          просмотры книги
likes:book:{id}         → "42"            лайки
liked:ip:{id}:{ip}      → "1"  (30 дней) защита от двойных лайков по IP
chapter-text:{id}       → "текст главы"   текст глав (до 25 МБ на значение)
```

## R2 — что хранится

```
covers/{bookId}.jpg     → обложки книг
```
