// functions/api/likes/[bookId].js
// GET  /api/likes/:bookId   — получить количество лайков
// POST /api/likes/:bookId   — поставить лайк

export async function onRequest(context) {
  const { request, env, params } = context;
  const bookId = params.bookId;
  const method = request.method;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (method === 'OPTIONS') return new Response(null, { headers });

  const kvKey = 'likes:book:' + bookId;

  if (method === 'GET') {
    const val = await env.KV.get(kvKey);
    return new Response(JSON.stringify({ likes: parseInt(val || '0') }), { headers });
  }

  if (method === 'POST') {
    // Базовая защита от дублей — по IP (CF-Connecting-IP)
    // Для более надёжной защиты лучше использовать fingerprint на клиенте (уже сделано)
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const ipKey = 'liked:ip:' + bookId + ':' + ip;

    const alreadyLiked = await env.KV.get(ipKey);
    if (alreadyLiked) {
      // Возвращаем текущее значение без инкремента
      const val = await env.KV.get(kvKey);
      return new Response(JSON.stringify({ likes: parseInt(val || '0'), duplicate: true }), { headers });
    }

    // Записываем что этот IP уже лайкнул (TTL 30 дней)
    await env.KV.put(ipKey, '1', { expirationTtl: 60 * 60 * 24 * 30 });

    const current = parseInt(await env.KV.get(kvKey) || '0');
    const next = current + 1;
    await env.KV.put(kvKey, String(next));

    // Синхронизируем с D1
    await env.DB.prepare('UPDATE books SET likes = ? WHERE id = ?')
      .bind(next, bookId).run().catch(() => {});

    return new Response(JSON.stringify({ likes: next }), { headers });
  }

  return new Response('Method Not Allowed', { status: 405, headers });
}
