// functions/api/stats.js
// GET /api/stats  — общая статистика (total views, books, chapters)

export async function onRequest(context) {
  const { request, env } = context;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (request.method === 'OPTIONS') return new Response(null, { headers });

  try {
    // Считаем суммарные просмотры из D1 (синхронизированы с KV)
    const viewsResult = await env.DB.prepare(
      'SELECT COALESCE(SUM(views), 0) AS total FROM books WHERE published = 1'
    ).first();

    const countsResult = await env.DB.prepare(`
      SELECT
        COUNT(DISTINCT b.id) AS total_books,
        COUNT(c.id) AS total_chapters
      FROM books b
      LEFT JOIN chapters c ON c.book_id = b.id AND c.published = 1
      WHERE b.published = 1
    `).first();

    return new Response(JSON.stringify({
      total_views:    viewsResult?.total || 0,
      total_books:    countsResult?.total_books || 0,
      total_chapters: countsResult?.total_chapters || 0,
    }), { headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
}
