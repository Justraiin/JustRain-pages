// functions/api/admin/books.js
// GET  /api/admin/books   — ВСЕ книги (включая неопубликованные), только admin

export async function onRequest(context) {
  const { request, env } = context;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (request.method === 'OPTIONS') return new Response(null, { headers });
  if (!isAdmin(request, env)) return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers });

  try {
    const { results } = await env.DB.prepare(`
      SELECT b.id, b.slug, b.title, b.author, b.genre, b.date, b.part,
             b.status, b.annotation, b.cover_url, b.published,
             b.views, b.likes,
             (SELECT COUNT(*) FROM chapters c WHERE c.book_id = b.id) AS chapters_count
      FROM books b
      ORDER BY b.created_at DESC
    `).all();

    return new Response(JSON.stringify(results), { headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
}

function isAdmin(request, env) {
  return request.headers.get('X-Admin-Key') === env.ADMIN_SECRET;
}
