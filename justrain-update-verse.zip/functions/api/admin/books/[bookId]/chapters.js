// functions/api/admin/books/[bookId]/chapters.js
// GET /api/admin/books/:bookId/chapters  — все главы книги (admin)

export async function onRequest(context) {
  const { request, env, params } = context;
  const bookId = params.bookId;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (request.method === 'OPTIONS') return new Response(null, { headers });
  if (!isAdmin(request, env)) return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers });

  try {
    const { results } = await env.DB.prepare(`
      SELECT id, book_id, number, title, published, created_at
      FROM chapters
      WHERE book_id = ?
      ORDER BY number ASC
    `).bind(bookId).all();

    return new Response(JSON.stringify(results), { headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
}

function isAdmin(request, env) {
  return request.headers.get('X-Admin-Key') === env.ADMIN_SECRET;
}
