// functions/api/views/[bookId].js
// GET  /api/views/:bookId   — получить счётчик просмотров
// POST /api/views/:bookId   — инкрементировать

export async function onRequest(context) {
  const { request, env, params } = context;
  const bookId = params.bookId;
  const method = request.method;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (method === 'OPTIONS') return new Response(null, { headers });

  const kvKey = 'views:book:' + bookId;

  if (method === 'GET') {
    const val = await env.KV.get(kvKey);
    return new Response(JSON.stringify({ views: parseInt(val || '0') }), { headers });
  }

  if (method === 'POST') {
    const current = parseInt(await env.KV.get(kvKey) || '0');
    const next = current + 1;
    await env.KV.put(kvKey, String(next));

    // Также обновляем в D1 для удобства запросов в статистике
    await env.DB.prepare('UPDATE books SET views = ? WHERE id = ?')
      .bind(next, bookId).run().catch(() => {});

    return new Response(JSON.stringify({ views: next }), { headers });
  }

  return new Response('Method Not Allowed', { status: 405, headers });
}
