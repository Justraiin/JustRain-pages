// functions/api/books.js
// GET  /api/books         — список опубликованных книг (для каталога)
// POST /api/books         — создать книгу (admin)

export async function onRequest(context) {
  const { request, env } = context;
  const method = request.method;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (method === 'OPTIONS') return new Response(null, { headers });

  // ── GET: публичный список книг ──
  if (method === 'GET') {
    try {
      const { results } = await env.DB.prepare(`
        SELECT b.id, b.slug, b.title, b.author, b.genre, b.date, b.part,
               b.status, b.annotation, b.cover_url, b.published,
               COUNT(c.id) AS chapters_count
        FROM books b
        LEFT JOIN chapters c ON c.book_id = b.id AND c.published = 1
        WHERE b.published = 1
        GROUP BY b.id
        ORDER BY b.created_at DESC
      `).all();

      // Добавляем просмотры и лайки из KV
      const enriched = await Promise.all(results.map(async book => {
        const [views, likes] = await Promise.all([
          env.KV.get('views:book:' + book.id),
          env.KV.get('likes:book:' + book.id),
        ]);
        return {
          ...book,
          views: parseInt(views || '0'),
          likes: parseInt(likes || '0'),
        };
      }));

      return new Response(JSON.stringify(enriched), { headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  // ── POST: создать книгу (только admin) ──
  if (method === 'POST') {
    if (!isAdmin(request, env)) return forbidden(headers);
    try {
      const body = await request.json();
      const { title, author, slug, genre, date, part, status, annotation } = body;

      if (!title || !slug) {
        return new Response(JSON.stringify({ error: 'title и slug обязательны' }), { status: 400, headers });
      }

      const id = crypto.randomUUID();
      await env.DB.prepare(`
        INSERT INTO books (id, slug, title, author, genre, date, part, status, annotation, published, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, datetime('now'))
      `).bind(id, slug, title, author || 'JustRain', genre || '', date || '', part || '1', status || 'В процессе', annotation || '').run();

      const book = await env.DB.prepare('SELECT * FROM books WHERE id = ?').bind(id).first();
      return new Response(JSON.stringify(book), { status: 201, headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  return new Response('Method Not Allowed', { status: 405, headers });
}

function isAdmin(request, env) {
  const key = request.headers.get('X-Admin-Key');
  // В реальности сравниваем с секретом из env
  return key && key === env.ADMIN_SECRET;
}

function forbidden(headers) {
  return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers });
}
