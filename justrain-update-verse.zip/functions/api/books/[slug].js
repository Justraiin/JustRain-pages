// functions/api/books/[slug].js
// GET   /api/books/:slug         — книга + главы (публично)
// PATCH /api/books/:slug         — обновить книгу (admin)
// DELETE /api/books/:slug        — удалить книгу (admin)

export async function onRequest(context) {
  const { request, env, params } = context;
  const slug   = params.slug;
  const method = request.method;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (method === 'OPTIONS') return new Response(null, { headers });

  // ── Находим книгу ──
  const isAdminReq = isAdmin(request, env);
  const book = await env.DB.prepare(
    'SELECT * FROM books WHERE slug = ? OR id = ?'
  ).bind(slug, slug).first();

  if (!book) {
    return new Response(JSON.stringify({ error: 'Книга не найдена' }), { status: 404, headers });
  }

  if (!book.published && !isAdminReq) {
    return new Response(JSON.stringify({ error: 'Книга не найдена' }), { status: 404, headers });
  }

  // ── GET ──
  if (method === 'GET') {
    // Главы — для публики только опубликованные, для admin все
    const chaptersQuery = isAdminReq
      ? 'SELECT id, book_id, number, title, published, created_at FROM chapters WHERE book_id = ? ORDER BY number ASC'
      : 'SELECT id, book_id, number, title, published, created_at FROM chapters WHERE book_id = ? AND published = 1 ORDER BY number ASC';

    const { results: chapters } = await env.DB.prepare(chaptersQuery).bind(book.id).all();

    const [views, likes] = await Promise.all([
      env.KV.get('views:book:' + book.id),
      env.KV.get('likes:book:' + book.id),
    ]);

    return new Response(JSON.stringify({
      book: {
        ...book,
        views: parseInt(views || '0'),
        likes: parseInt(likes || '0'),
      },
      chapters,
    }), { headers });
  }

  // ── PATCH: обновить ──
  if (method === 'PATCH') {
    if (!isAdminReq) return forbidden(headers);
    try {
      const body = await request.json();
      const fields = [];
      const values = [];

      const allowed = ['title','author','slug','genre','date','part','status','annotation','cover_url','published'];
      for (const key of allowed) {
        if (key in body) {
          fields.push(`${key} = ?`);
          values.push(body[key]);
        }
      }

      if (!fields.length) {
        return new Response(JSON.stringify({ error: 'Нет полей для обновления' }), { status: 400, headers });
      }

      values.push(book.id);
      await env.DB.prepare(
        `UPDATE books SET ${fields.join(', ')} WHERE id = ?`
      ).bind(...values).run();

      const updated = await env.DB.prepare('SELECT * FROM books WHERE id = ?').bind(book.id).first();
      return new Response(JSON.stringify(updated), { headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  // ── DELETE ──
  if (method === 'DELETE') {
    if (!isAdminReq) return forbidden(headers);
    try {
      // Удаляем обложку из R2 если есть
      if (book.cover_url) {
        const key = book.cover_url.split('/').slice(-1)[0]; // последний сегмент пути
        await env.R2.delete('covers/' + key).catch(() => {});
      }

      // Удаляем главы и книгу
      await env.DB.prepare('DELETE FROM chapters WHERE book_id = ?').bind(book.id).run();
      await env.DB.prepare('DELETE FROM books WHERE id = ?').bind(book.id).run();

      // Удаляем KV счётчики
      await Promise.all([
        env.KV.delete('views:book:' + book.id),
        env.KV.delete('likes:book:' + book.id),
      ]);

      return new Response(JSON.stringify({ ok: true }), { headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  return new Response('Method Not Allowed', { status: 405, headers });
}

function isAdmin(request, env) {
  return request.headers.get('X-Admin-Key') === env.ADMIN_SECRET;
}

function forbidden(headers) {
  return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers });
}
