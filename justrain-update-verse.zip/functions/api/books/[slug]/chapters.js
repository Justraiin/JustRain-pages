// functions/api/books/[slug]/chapters.js
// GET  /api/books/:slug/chapters   — все главы книги (admin: все, публично: опубл.)
// POST /api/books/:slug/chapters   — создать главу (admin)

export async function onRequest(context) {
  const { request, env, params } = context;
  const method = request.method;
  const slug   = params.slug;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (method === 'OPTIONS') return new Response(null, { headers });

  const isAdminReq = isAdmin(request, env);

  const book = await env.DB.prepare('SELECT * FROM books WHERE slug = ? OR id = ?')
    .bind(slug, slug).first();
  if (!book) return new Response(JSON.stringify({ error: 'Книга не найдена' }), { status: 404, headers });

  // ── GET ──
  if (method === 'GET') {
    const q = isAdminReq
      ? 'SELECT id, book_id, number, title, published, created_at FROM chapters WHERE book_id = ? ORDER BY number ASC'
      : 'SELECT id, book_id, number, title, published, created_at FROM chapters WHERE book_id = ? AND published = 1 ORDER BY number ASC';

    const { results } = await env.DB.prepare(q).bind(book.id).all();
    return new Response(JSON.stringify(results), { headers });
  }

  // ── POST: создать главу ──
  if (method === 'POST') {
    if (!isAdminReq) return forbidden(headers);

    try {
      const body = await request.json();
      const { title, text, published } = body;

      if (!title) return new Response(JSON.stringify({ error: 'title обязателен' }), { status: 400, headers });

      // Автонумерация
      const last = await env.DB.prepare(
        'SELECT MAX(number) AS max_num FROM chapters WHERE book_id = ?'
      ).bind(book.id).first();
      const number = (last?.max_num || 0) + 1;

      const id = crypto.randomUUID();

      // Текст главы храним в KV (быстрее и дешевле чем D1 для больших текстов)
      if (text) {
        await env.KV.put('chapter-text:' + id, text);
      }

      await env.DB.prepare(`
        INSERT INTO chapters (id, book_id, number, title, published, created_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `).bind(id, book.id, number, title, published ? 1 : 0).run();

      // Обновляем счётчик глав книги
      await env.DB.prepare(
        'UPDATE books SET chapters_count = (SELECT COUNT(*) FROM chapters WHERE book_id = ?) WHERE id = ?'
      ).bind(book.id, book.id).run();

      const chapter = await env.DB.prepare('SELECT * FROM chapters WHERE id = ?').bind(id).first();
      return new Response(JSON.stringify(chapter), { status: 201, headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  return new Response('Method Not Allowed', { status: 405, headers });
}

function isAdmin(request, env) {
  return request.headers.get('X-Admin-Key') === env.ADMIN_SECRET;
}
function forbidden(headers) {
  return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers });
}
