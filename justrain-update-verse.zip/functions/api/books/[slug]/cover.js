// functions/api/books/[slug]/cover.js
// POST /api/books/:slug/cover  — загрузить обложку в R2

export async function onRequest(context) {
  const { request, env, params } = context;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (request.method === 'OPTIONS') return new Response(null, { headers });
  if (!isAdmin(request, env)) return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers });

  const slug = params.slug;
  const book = await env.DB.prepare('SELECT * FROM books WHERE slug = ? OR id = ?').bind(slug, slug).first();
  if (!book) return new Response(JSON.stringify({ error: 'Книга не найдена' }), { status: 404, headers });

  // ── POST: загрузить новую обложку ──
  if (request.method === 'POST') {
    try {
      const formData = await request.formData();
      const file = formData.get('cover');

      if (!file) return new Response(JSON.stringify({ error: 'Файл не найден' }), { status: 400, headers });

      const ext = file.name.split('.').pop().toLowerCase() || 'jpg';
      const allowed = ['jpg', 'jpeg', 'png', 'webp', 'avif'];
      if (!allowed.includes(ext)) {
        return new Response(JSON.stringify({ error: 'Недопустимый формат файла' }), { status: 400, headers });
      }

      // Удаляем старую обложку
      if (book.cover_url) {
        const oldKey = 'covers/' + book.id + '.' + book.cover_url.split('.').pop();
        await env.R2.delete(oldKey).catch(() => {});
      }

      const r2Key = `covers/${book.id}.${ext}`;
      const arrayBuffer = await file.arrayBuffer();

      await env.R2.put(r2Key, arrayBuffer, {
        httpMetadata: { contentType: file.type || 'image/jpeg' },
      });

      // Публичный URL обложки
      // R2 публичный домен настраивается в Cloudflare dashboard
      const coverUrl = `${env.R2_PUBLIC_URL}/${r2Key}`;

      await env.DB.prepare('UPDATE books SET cover_url = ? WHERE id = ?')
        .bind(coverUrl, book.id).run();

      return new Response(JSON.stringify({ cover_url: coverUrl }), { headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  // ── DELETE: удалить обложку ──
  if (request.method === 'DELETE') {
    try {
      if (book.cover_url) {
        const ext = book.cover_url.split('.').pop();
        await env.R2.delete(`covers/${book.id}.${ext}`).catch(() => {});
      }
      await env.DB.prepare('UPDATE books SET cover_url = NULL WHERE id = ?').bind(book.id).run();
      return new Response(JSON.stringify({ ok: true }), { headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  return new Response('Method Not Allowed', { status: 405, headers });
}

function isAdmin(request, env) {
  return request.headers.get('X-Admin-Key') === env.ADMIN_SECRET;
}
