// functions/api/chapters/[id].js
// GET    /api/chapters/:id        — данные главы
// PATCH  /api/chapters/:id        — обновить (admin)
// DELETE /api/chapters/:id        — удалить (admin)

export async function onRequest(context) {
  const { request, env, params } = context;
  const id     = params.id;
  const method = request.method;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (method === 'OPTIONS') return new Response(null, { headers });

  const chapter = await env.DB.prepare('SELECT * FROM chapters WHERE id = ?').bind(id).first();
  if (!chapter) return new Response(JSON.stringify({ error: 'Глава не найдена' }), { status: 404, headers });

  const isAdminReq = isAdmin(request, env);

  // ── GET ──
  if (method === 'GET') {
    if (!chapter.published && !isAdminReq) {
      return new Response(JSON.stringify({ error: 'Глава не найдена' }), { status: 404, headers });
    }
    return new Response(JSON.stringify(chapter), { headers });
  }

  // ── PATCH ──
  if (method === 'PATCH') {
    if (!isAdminReq) return forbidden(headers);
    try {
      const body = await request.json();
      const { title, published, text } = body;

      // Обновляем текст в KV если передан
      if (typeof text === 'string') {
        await env.KV.put('chapter-text:' + id, text);
      }

      const fields = [];
      const values = [];

      if (title !== undefined)     { fields.push('title = ?');     values.push(title); }
      if (published !== undefined) { fields.push('published = ?'); values.push(published ? 1 : 0); }

      if (fields.length) {
        values.push(id);
        await env.DB.prepare(`UPDATE chapters SET ${fields.join(', ')} WHERE id = ?`)
          .bind(...values).run();
      }

      const updated = await env.DB.prepare('SELECT * FROM chapters WHERE id = ?').bind(id).first();
      return new Response(JSON.stringify(updated), { headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  // ── DELETE ──
  if (method === 'DELETE') {
    if (!isAdminReq) return forbidden(headers);
    try {
      const bookId = chapter.book_id;

      await env.KV.delete('chapter-text:' + id).catch(() => {});
      await env.DB.prepare('DELETE FROM chapters WHERE id = ?').bind(id).run();

      // Перенумерация
      const { results: remaining } = await env.DB.prepare(
        'SELECT id FROM chapters WHERE book_id = ? ORDER BY number ASC'
      ).bind(bookId).all();

      for (let i = 0; i < remaining.length; i++) {
        await env.DB.prepare('UPDATE chapters SET number = ? WHERE id = ?')
          .bind(i + 1, remaining[i].id).run();
      }

      // Обновить счётчик
      await env.DB.prepare(
        'UPDATE books SET chapters_count = (SELECT COUNT(*) FROM chapters WHERE book_id = ?) WHERE id = ?'
      ).bind(bookId, bookId).run();

      return new Response(JSON.stringify({ ok: true }), { headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }

  return new Response('Method Not Allowed', { status: 405, headers });
}

function isAdmin(request, env) {
  return request.headers.get('X-Admin-Key') === env.ADMIN_SECRET;
}
function forbidden(headers) {
  return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers });
}
