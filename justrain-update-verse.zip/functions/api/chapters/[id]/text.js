// functions/api/chapters/[id]/text.js
// GET /api/chapters/:id/text   — текст главы (из KV)

export async function onRequest(context) {
  const { request, env, params } = context;
  const id = params.id;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-Admin-Key',
  };

  if (request.method === 'OPTIONS') return new Response(null, { headers });

  // Проверяем что глава существует и опубликована (или admin)
  const chapter = await env.DB.prepare('SELECT id, published FROM chapters WHERE id = ?').bind(id).first();
  if (!chapter) return new Response(JSON.stringify({ error: 'Не найдено' }), { status: 404, headers });

  const isAdminReq = request.headers.get('X-Admin-Key') === env.ADMIN_SECRET;
  if (!chapter.published && !isAdminReq) {
    return new Response(JSON.stringify({ error: 'Не найдено' }), { status: 404, headers });
  }

  // Для reader отдаём plain text (reader.html использует это)
  const acceptHeader = request.headers.get('Accept') || '';
  const wantsJson = acceptHeader.includes('application/json') || isAdminReq;

  const text = await env.KV.get('chapter-text:' + id) || '';

  if (wantsJson) {
    return new Response(JSON.stringify({ text }), { headers });
  }

  // Plain text для fetch() в reader.html
  return new Response(text, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
    }
  });
}
